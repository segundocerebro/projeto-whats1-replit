# Diagnostics Summary (20250803_182252)
## Key Files Present
.replit
pyproject.toml
poetry.lock
README.md

## Top 10 Largest Files
382M	.
274M	./.cache
257M	./.cache/uv
198M	./.cache/uv/archive-v0
59M	./.cache/uv/archive-v0/NvZ3rMD266w7KF7V2P3RB
58M	./.cache/uv/simple-v14/pypi
58M	./.cache/uv/simple-v14
47M	./.pythonlibs
46M	./.pythonlibs/lib/python3.11/site-packages
46M	./.pythonlibs/lib/python3.11

## Recent Changes (2d) – Files
./app/clients/elevenlabs_client.py
./app/clients/__init__.py
./app/clients/openai_client.py
./app/clients/__pycache__/elevenlabs_client.cpython-311.pyc
./app/clients/__pycache__/__init__.cpython-311.pyc
./app/clients/__pycache__/openai_client.cpython-311.pyc
./app/clients/__pycache__/twilio_client.cpython-311.pyc
./app/clients/twilio_client.py
./app/core/__init__.py
./app/core/__pycache__/__init__.cpython-311.pyc
./app/core/__pycache__/rag_manager.cpython-311.pyc
./app/functions.py
./app/__init__.py
./app/models.py
./app/__pycache__/functions.cpython-311.pyc
./app/__pycache__/__init__.cpython-311.pyc
./app/__pycache__/models.cpython-311.pyc
./app/__pycache__/routes.cpython-311.pyc
./app/__pycache__/services.cpython-311.pyc
./app/routes.py

## Found Logs
2 _diag_20250803_182252/logs/_found_logs.txt
